package com.capgemini.mcdonald.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.mcdonald.model.PersonDetails;

@Repository
public interface PersonInterface extends CrudRepository<PersonDetails, Integer>{

}
