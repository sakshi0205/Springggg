package com.hds.service;

import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.hds.model.Market;
import com.hds.repository.MarketRepository;

@Service
@Transactional
public abstract  class MarketImpl implements IMarket {
	@Autowired
	MarketRepository repository;
	

	public List<Market> showMarket(long marketid) {
		List<Market> list  = repository.findByMarket(marketid);
		return list;
	}
		
	

		

}
