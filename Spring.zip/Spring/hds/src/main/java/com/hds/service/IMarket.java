package com.hds.service;

import java.util.List;


import com.hds.model.Market;



public interface IMarket {
	
	public List<Market> showMarket(long marketid);
}
