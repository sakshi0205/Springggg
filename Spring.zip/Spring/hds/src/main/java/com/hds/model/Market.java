package com.hds.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Table(name="markets")
@Entity
public class Market {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "marketid")
	@Id
	private long marketid;
	@Column(name = "market")
	private String market;
	@Column(name = "region")
	private String region;	
	@Column(name = "noofstore")
	private String noofstore;
	@Column(name = "noofvendor")
	private String noofvendor;
	
	
	
	public long getMarketid() {
		return marketid;
	}
	public void setMarketid(long marketid) {
		this.marketid = marketid;
	}
	
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getNoofstore() {
		return noofstore;
	}
	public void setNoofstore(String noofstore) {
		this.noofstore = noofstore;
	}
	public String getNoofvendor() {
		return noofvendor;
	}
	public void setNoofvendor(String noofvendor) {
		this.noofvendor = noofvendor;
	}
	
	
}
	
