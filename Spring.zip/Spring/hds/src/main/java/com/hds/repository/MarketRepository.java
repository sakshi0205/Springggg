package com.hds.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.hds.model.Market;



public interface MarketRepository extends JpaRepository<Market,Long>{
	
	@Query("from Market m where m.market =  ?1")
	public List<Market> findByMarket(long marketid);


	
}
