package com.hds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HdsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdsApplication.class, args);
	}

}
