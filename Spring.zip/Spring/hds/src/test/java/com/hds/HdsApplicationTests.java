package com.hds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HdsApplicationTests {

	@Test
	void contextLoads() {
	}

}
